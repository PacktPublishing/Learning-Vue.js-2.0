# Section 1 Code Examples

For this section you don't need any command line tools, you can just open the `index.html` files and play around with them.
