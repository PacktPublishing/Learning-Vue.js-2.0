<template>
  <div class="about">
    <h1>This is an about page</h1>
    <p>Hey! If you've made it this far in the course, <a href="https://twitter.com/JonathanMH_com" target="twitter_author">give me a shout on Twitter</a> 🐦🐦🐦!</p>
  </div>
</template>
