<template>
  <div class="global-component">
    <h2>Check out these cool Vue plugins!</h2>
    <ul>
      <li><a target="_github-vue-youtube" href="https://github.com/anteriovieira/vue-youtube">vue-youtube</a></li>
      <li><a target="_github-vuejs-storage" href="https://github.com/maple3142/vuejs-storage">vuejs-storage</a></li>
    </ul>
  </div>
</template>