# Section 2 Code

Remember to have the [Vue CLI](https://cli.vuejs.org/) installed and if one of the code examples does not work, try running `npm install` first.

Happy hacking!
